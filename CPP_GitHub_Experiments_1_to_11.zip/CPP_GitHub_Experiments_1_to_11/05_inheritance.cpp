#include <iostream>
#include <string>
using namespace std;

// Single inheritance: Student inherits Person.
class Person {
protected:
    string name;
    int age;
public:
    Person(string n, int a) : name(n), age(a) {}
    void showPerson() const {
        cout << "Name: " << name << "\nAge: " << age << '\n';
    }
};

// Multilevel inheritance: GraduateStudent inherits Student, which inherits Person.
class Student : public Person {
protected:
    int rollNo;
public:
    Student(string n, int a, int r) : Person(n, a), rollNo(r) {}
    void showStudent() const {
        showPerson();
        cout << "Roll number: " << rollNo << '\n';
    }
};

class GraduateStudent : public Student {
private:
    string researchTopic;
public:
    GraduateStudent(string n, int a, int r, string topic)
        : Student(n, a, r), researchTopic(topic) {}

    void display() const {
        showStudent();
        cout << "Research topic: " << researchTopic << '\n';
    }
};

int main() {
    GraduateStudent g("Anaya", 22, 101, "Artificial Intelligence");
    g.display();
    return 0;
}

#include <iostream>
using namespace std;

class Logger {
private:
    Logger() {
        cout << "Logger instance created.\n";
    }

    Logger(const Logger&) = delete;
    Logger& operator=(const Logger&) = delete;

public:
    static Logger& getInstance() {
        static Logger instance; // created once; thread-safe since C++11
        return instance;
    }

    void log(string message) {
        cout << "[LOG] " << message << '\n';
    }
};

int main() {
    Logger& logger1 = Logger::getInstance();
    logger1.log("Application started.");

    Logger& logger2 = Logger::getInstance();
    logger2.log("Second request uses the same instance.");

    cout << "Same object? " << boolalpha << (&logger1 == &logger2) << '\n';
    return 0;
}

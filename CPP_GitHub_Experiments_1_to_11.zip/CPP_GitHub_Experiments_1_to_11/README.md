# C++ Practical Experiments 1–11

This repository contains separate, beginner-friendly C++17 programs for experiments 1 to 11 from the supplied practical list.

## Files
1. `01_basics.cpp` — data types, constants, variables, operators and input/output
2. `02_class_hierarchy.cpp` — class, access specifiers and member functions
3. `03_constructors_rule_of_five.cpp` — default, parameterized, copy and move constructors; Rule of Five
4. `04_raii_smart_pointers.cpp` — `unique_ptr` and `shared_ptr`
5. `05_inheritance.cpp` — single and multilevel inheritance
6. `06_runtime_polymorphism.cpp` — abstract base class and virtual `area()` function
7. `07_compile_time_polymorphism.cpp` — function and operator overloading using Complex numbers
8. `08_singleton.cpp` — Singleton design pattern
9. `09_template_stack.cpp` — generic Stack template
10. `10_stl_student_marks.cpp` — vector, map, unordered_map and STL algorithms
11. `11_custom_exceptions.cpp` — custom exception hierarchy for banking transactions

## Compile and run
Using g++:

```bash
g++ -std=c++17 01_basics.cpp -o program
./program
```

Replace the filename for each experiment. On Windows, run `program.exe`.

## Experiment 3: Valgrind (Linux)
Compile with debug information and run:

```bash
g++ -std=c++17 -g 03_constructors_rule_of_five.cpp -o exp3
valgrind --leak-check=full --show-leak-kinds=all ./exp3
```

## Experiment 4: memory usage
The smart-pointer example demonstrates automatic lifetime management. You can inspect it with:

```bash
g++ -std=c++17 -g 04_raii_smart_pointers.cpp -o exp4
valgrind --leak-check=full ./exp4
```

## GitHub setup
Create a new repository on GitHub, then from this folder run:

```bash
git init
git add .
git commit -m "Add C++ practical experiments 1 to 11"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Replace the remote URL with your own repository URL.

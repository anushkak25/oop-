#include <iostream>
using namespace std;

class Complex {
private:
    double real, imag;

public:
    Complex(double r = 0, double i = 0) : real(r), imag(i) {}

    // Function overloading
    void display() const {
        cout << real << (imag >= 0 ? " + " : " - ")
             << (imag >= 0 ? imag : -imag) << "i\n";
    }
    void display(string label) const {
        cout << label;
        display();
    }

    // Operator overloading
    Complex operator+(const Complex& other) const {
        return Complex(real + other.real, imag + other.imag);
    }
};

int main() {
    Complex first(4, 3), second(2, 5);
    first.display("First number: ");
    second.display("Second number: ");

    Complex result = first + second;
    result.display("Addition: ");
    return 0;
}

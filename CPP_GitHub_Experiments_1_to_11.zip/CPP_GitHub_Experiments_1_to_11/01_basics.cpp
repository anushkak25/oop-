#include <iostream>
#include <string>
using namespace std;

int main() {
    int age;
    const double PI = 3.14159;
    double radius;

    cout << "Enter your age: ";
    cin >> age;

    cout << "Enter circle radius: ";
    cin >> radius;

    double area = PI * radius * radius;

    cout << "\n--- Basic C++ Demonstration ---\n";
    cout << "Integer (age): " << age << '\n';
    cout << "Constant PI: " << PI << '\n';
    cout << "Radius: " << radius << '\n';
    cout << "Area of circle: " << area << '\n';
    cout << "Age next year: " << age + 1 << '\n';
    cout << "Is age above 18? " << (age > 18) << '\n';
    return 0;
}

#include <iostream>
#include <memory>
#include <utility>
using namespace std;

class Student {
public:
    string name;
    explicit Student(string n) : name(move(n)) {
        cout << name << " created\n";
    }
    ~Student() {
        cout << name << " destroyed automatically\n";
    }
};

int main() {
    cout << "unique_ptr example:\n";
    {
        unique_ptr<Student> student1 = make_unique<Student>("Riya");
        cout << "Student: " << student1->name << '\n';

        unique_ptr<Student> student2 = move(student1);
        cout << "Ownership transferred to student2.\n";
        cout << "Student: " << student2->name << '\n';
    }

    cout << "\nshared_ptr example:\n";
    {
        shared_ptr<Student> first = make_shared<Student>("Kabir");
        {
            shared_ptr<Student> second = first;
            cout << "Owners: " << first.use_count() << '\n';
        }
        cout << "Owners after inner scope: " << first.use_count() << '\n';
    }
    return 0;
}

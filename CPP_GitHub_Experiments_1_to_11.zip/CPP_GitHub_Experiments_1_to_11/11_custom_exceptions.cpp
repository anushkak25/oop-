#include <iostream>
#include <stdexcept>
#include <string>
using namespace std;

class BankingException : public runtime_error {
public:
    explicit BankingException(const string& message) : runtime_error(message) {}
};

class InsufficientFunds : public BankingException {
public:
    InsufficientFunds() : BankingException("Insufficient balance.") {}
};

class InvalidAmount : public BankingException {
public:
    InvalidAmount() : BankingException("Amount must be greater than zero.") {}
};

class BankAccount {
private:
    double balance;

public:
    explicit BankAccount(double initialBalance) : balance(initialBalance) {}

    void deposit(double amount) {
        if (amount <= 0) throw InvalidAmount();
        balance += amount;
        cout << "Deposit successful. Balance: Rs. " << balance << '\n';
    }

    void withdraw(double amount) {
        if (amount <= 0) throw InvalidAmount();
        if (amount > balance) throw InsufficientFunds();
        balance -= amount;
        cout << "Withdrawal successful. Balance: Rs. " << balance << '\n';
    }
};

int main() {
    BankAccount account(5000);

    try {
        account.deposit(1000);
        account.withdraw(2000);
        account.withdraw(10000);
    } catch (const InvalidAmount& e) {
        cout << "Invalid transaction: " << e.what() << '\n';
    } catch (const InsufficientFunds& e) {
        cout << "Transaction failed: " << e.what() << '\n';
    } catch (const BankingException& e) {
        cout << "Banking error: " << e.what() << '\n';
    } catch (const exception& e) {
        cout << "Unexpected error: " << e.what() << '\n';
    }

    return 0;
}

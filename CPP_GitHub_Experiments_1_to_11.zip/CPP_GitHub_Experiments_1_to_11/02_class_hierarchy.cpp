#include <iostream>
#include <string>
using namespace std;

class BankAccount {
private:
    string accountHolder;
    double balance;

protected:
    void showAccountType() const {
        cout << "Account type: Savings\n";
    }

public:
    BankAccount(string name, double amount)
        : accountHolder(name), balance(amount) {}

    void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            cout << "Deposit successful.\n";
        } else {
            cout << "Invalid deposit amount.\n";
        }
    }

    void display() const {
        cout << "Holder: " << accountHolder << '\n';
        cout << "Balance: Rs. " << balance << '\n';
        showAccountType();
    }
};

int main() {
    BankAccount account("Aarav", 5000);
    account.display();
    account.deposit(1500);
    account.display();
    return 0;
}

#include <iostream>
#include <vector>
#include <string>
#include <stdexcept>
using namespace std;

template <typename T>
class Stack {
private:
    vector<T> items;

public:
    void push(const T& value) {
        items.push_back(value);
    }

    void pop() {
        if (items.empty()) {
            cout << "Stack is empty.\n";
            return;
        }
        items.pop_back();
    }

    T top() const {
        if (items.empty()) throw runtime_error("Stack is empty");
        return items.back();
    }

    bool empty() const {
        return items.empty();
    }

    void display() const {
        for (auto it = items.rbegin(); it != items.rend(); ++it)
            cout << *it << '\n';
    }
};

int main() {
    Stack<int> intStack;
    intStack.push(10);
    intStack.push(20);
    cout << "Integer top: " << intStack.top() << '\n';

    Stack<float> floatStack;
    floatStack.push(2.5f);
    floatStack.push(4.5f);
    cout << "Float top: " << floatStack.top() << '\n';

    Stack<string> stringStack;
    stringStack.push("C++");
    stringStack.push("Templates");
    cout << "String top: " << stringStack.top() << '\n';
    return 0;
}

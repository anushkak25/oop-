#include <iostream>
#include <vector>
#include <map>
#include <unordered_map>
#include <algorithm>
#include <numeric>
using namespace std;

struct Student {
    int roll;
    string name;
    int marks;
};

int main() {
    vector<Student> students = {
        {103, "Asha", 82},
        {101, "Rohan", 67},
        {104, "Meera", 91},
        {102, "Dev", 74}
    };

    // map stores roll numbers in sorted key order.
    map<int, string> studentNames;
    // unordered_map provides average constant-time lookup (on average).
    unordered_map<int, int> studentMarks;

    for (const auto& s : students) {
        studentNames[s.roll] = s.name;
        studentMarks[s.roll] = s.marks;
    }

    // sort algorithm
    sort(students.begin(), students.end(),
         [](const Student& a, const Student& b) {
             return a.marks > b.marks;
         });

    cout << "Students sorted by marks:\n";
    for (const auto& s : students)
        cout << s.roll << " " << s.name << " " << s.marks << '\n';

    // find_if algorithm
    auto passed = find_if(students.begin(), students.end(),
                          [](const Student& s) { return s.marks >= 75; });
    if (passed != students.end())
        cout << "\nFirst student with 75 or more: " << passed->name << '\n';

    // transform algorithm: extract marks
    vector<int> marks(students.size());
    transform(students.begin(), students.end(), marks.begin(),
              [](const Student& s) { return s.marks; });

    int total = accumulate(marks.begin(), marks.end(), 0);
    cout << "Average marks: " << static_cast<double>(total) / marks.size() << '\n';

    cout << "\nLookup roll 102: " << studentNames[102]
         << ", marks = " << studentMarks[102] << '\n';
    return 0;
}

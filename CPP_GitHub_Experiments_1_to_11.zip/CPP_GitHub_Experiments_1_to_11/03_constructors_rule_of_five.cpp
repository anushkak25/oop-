#include <iostream>
#include <algorithm>
#include <utility>
using namespace std;

class NumberArray {
private:
    int* data;
    int size;

public:
    // Default constructor
    NumberArray() : data(nullptr), size(0) {
        cout << "Default constructor\n";
    }

    // Parameterized constructor
    explicit NumberArray(int n) : data(n > 0 ? new int[n] : nullptr), size(max(0, n)) {
        for (int i = 0; i < size; ++i) data[i] = i + 1;
        cout << "Parameterized constructor\n";
    }

    // Copy constructor: deep copy
    NumberArray(const NumberArray& other)
        : data(other.size ? new int[other.size] : nullptr), size(other.size) {
        for (int i = 0; i < size; ++i) data[i] = other.data[i];
        cout << "Copy constructor\n";
    }

    // Move constructor
    NumberArray(NumberArray&& other) noexcept : data(other.data), size(other.size) {
        other.data = nullptr;
        other.size = 0;
        cout << "Move constructor\n";
    }

    // Copy assignment operator
    NumberArray& operator=(const NumberArray& other) {
        if (this != &other) {
            int* newData = other.size ? new int[other.size] : nullptr;
            for (int i = 0; i < other.size; ++i) newData[i] = other.data[i];
            delete[] data;
            data = newData;
            size = other.size;
        }
        cout << "Copy assignment\n";
        return *this;
    }

    // Move assignment operator
    NumberArray& operator=(NumberArray&& other) noexcept {
        if (this != &other) {
            delete[] data;
            data = other.data;
            size = other.size;
            other.data = nullptr;
            other.size = 0;
        }
        cout << "Move assignment\n";
        return *this;
    }

    // Destructor
    ~NumberArray() {
        delete[] data;
        cout << "Destructor\n";
    }

    void display() const {
        for (int i = 0; i < size; ++i) cout << data[i] << ' ';
        cout << '\n';
    }
};

int main() {
    NumberArray a;                 // default
    NumberArray b(3);              // parameterized
    b.display();
    NumberArray c = b;             // copy
    c.display();
    NumberArray d = move(b);       // move
    d.display();

    NumberArray e(2);
    e = c;                         // copy assignment
    e = move(d);                   // move assignment
    e.display();
    return 0;
}
